﻿// Volatility Workbench software
// Main header file
// Copyright PassMark 2023
// www.passmark.com
//
// Volatility Workbecnch is free software; you can redistribute it and / or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Volatility Workbecnch is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Volatility.If not, see <http://www.gnu.org/licenses/>.

#ifndef VOLATILITY_WORKBENCH_H
#define VOLATILITY_WORKBENCH_H

#include "resource.h"

#define	COMPANY_NAME				L"PassMark"

#define PROGRAM_NAME				L"Volatility Workbench"
#define PROGRAM_VERSION				L"V3.0"
#define PROGRAM_BUILD				L"1011"
#define	PASSMARK_WEBSITE			L"https://www.passmark.com"
#define VOLATILITY_EXE				L"vol.exe"
#define VOLATILITY_VER				L"2.11.0"
#define	VOLATILITY_WEBSITE			L"https://www.volatilityfoundation.org"

#define MIN_WINDOW_WIDTH			1050	//Minimum dialog width
#define MIN_WINDOW_HEIGHT			700		//Minimum dialog height
#define WEBCTRL_OFFSET_X			15		//X Offset of web control in the dialog
#define WEBCTRL_OFFSET_Y			210		//Y Offset of web cotnrol int the dialog
#define WEBCTRL_WIDTHOFFSET_X		30		//Offset for width of web control 
#define WEBCTRL_HEIGHTOFFSET_X		260		//Offset for height of web control 

#define MAXDIRNAME					300
#define	MAXFILENAME					200
#define	MAXPARAMETERSLEN			500
#define MAX_SEARCH_STRING_LEN		300		//maximum search string lenght
#define MAX_ENVIRONMENT_STRING_LEN	2024
#define MAX_URL_LEN					2048
#define MAX_HEADER_TEXT_LEN			1024
#define MAX_RESULT_BUFF_LEN			1048576
#define	INIT_HTML_BUFF_LEN			1024
#define OK							true
#define NOK							false
#define NUM_OF_FILES				150
#define	NUM_SCRIPTS					20

//Window resizing modes
#define	RS_MOVE						0
#define	RS_RESIZE					1
#define	RS_MOVE_DOWN				2
#define	RS_MOVE_ACROSS				3
#define	RS_RESIZE_HALFY				4
#define	RS_MOVE_ACROSS_SIZE_DOWN	5
#define	RS_MOVE_DOWN_SIZE_ACROSS	6
#define	RS_MOVE_DOWN_AND_ACROSS		7
#define	RS_SIZE_ACROSS				8

//Image positioning
#define	IMAGE_OFFSET				0
#define	IMAGE_HEIGHT				102

#define	NUM_PLATFORMS				3
#define TOT_COMMANDS				134
#define	TOT_SCRIPTS					1
#define	NUM_PROFILES				200
#define NUM_BASE_PROFILES			54
#define	MAX_NUM_PARAM				10
#define	MAX_KDBG_ADDR_LEN			20
#define	MAX_COM_STR_LEN				10
#define	MAX_NUM_PROCESS				500
#define	MAX_PROCESS_LEN				50

#define	MAX_NUM_VALUEITEMS			2000
#define	MAX_VALUE_LEN				50

#define	CHECKTYPE_NOCHECKBOX		0
#define	CHECKTYPE_CHECKBOX			1
#define	CHECKTYPE_RADIOBUTTON		2

#define	VALUETYPE_NOVALUE			0
#define	VALUETYPE_EDITBOX			1
#define	VALUETYPE_COMBOBOX			2

#define	VALIDATION_DISABLED			0
#define	VALIDATION_DIGIT			1
#define	VALIDATION_HEXADDRESS		2
#define	VALIDATION_REGEX			3
#define	VALIDATION_DIR				4

#define	READ_SIZE					64

typedef enum CURSOR_TYPE
{
	ARROW = 0,
	WAIT
};

typedef struct ParamValue_t
{
	int			NumItems;
	wchar_t		Name[MAX_NUM_VALUEITEMS][MAX_VALUE_LEN];
	wchar_t		Value[MAX_NUM_VALUEITEMS][MAX_VALUE_LEN];
};

struct VOLATILITY_PARAM_TYPEDEF
{
	wchar_t*		pszLabelText;
	wchar_t*		pszParam;
	bool			bPluginParam;
	char			CheckType;
	int				nCheckDlgID;
	bool			bChecked;
	char			ValueType;
	int				nValueDlgID;
	ParamValue_t*	ValueList;
	char			ValidationType;
};

#define CMD_PARAM (_LABELTXT, _PARAM, _CHECKBOXTYPE, _CHECKID, _CHECKED, _VALUETYPE, _VALUEID) {_LABELTXT, _PARAM, _CHECKBOXTYPE, _CHECKID, _CHECKED, _VALUETYPE, _VALUEID}
#define NOPARAM		{L"", L"", CHECKTYPE_NOCHECKBOX, 0, 0, VALUETYPE_NOVALUE, 0}

typedef struct VOLATILITY_CMD_TYPEDEF
{
	wchar_t*	pszPlatform;
	wchar_t*	pszCommand;
	wchar_t*	pszDescription;
	int			nParams;
	VOLATILITY_PARAM_TYPEDEF	params[MAX_NUM_PARAM];
};

#define VOLATILITY_COMMAND (_CMD, _DESCRIPTION, _NUMPARAM, _PARAM1, _PARAM2, _PARAM3, _PARAM4, _PARAM5, _PARAM6, _PARAM7, _PARAM8, _PARAM9, _PARAM10)	{ _CMD, _DESCRIPTION, _NUMPARAM, { _PARAM1, _PARAM2, _PARAM3, _PARAM4, _PARAM5, _PARAM6, _PARAM7, _PARAM8, _PARAM9, _PARAM10 } }

typedef struct VOLATILITY_PROFILE_TYPEDEF
{
	wchar_t*	Profile;
	wchar_t*	Description;
};

#define VOLATILITY_PROFILE(PROFILE, DESCRIPTION)	{PROFILE, DESCRIPTION}

typedef struct CONFIG
{
	wchar_t		Profile[MAX_PROFILE_LEN];
	wchar_t		KDBG_Addr[MAX_KDBG_ADDR_LEN];
	int			ProcessCount;
	wchar_t		ProcessName[MAX_NUM_PROCESS][MAX_PROCESS_LEN];
	wchar_t		PID[MAX_NUM_PROCESS][MAX_PROCESS_LEN];
};

// Global variables
#if defined (MAIN_MODULE)
HWND					ghMainWnd; //Main window
char					lastURL[MAX_URL_LEN]; //last URL that was clicked and needs processing
wchar_t					fullpath[MAXFILENAME + MAXDIRNAME] = { L'\0' }; //Work area, temp var
wchar_t					RunDirName[MAXDIRNAME];
wchar_t					szDefaultLogName[MAXFILENAME] = L"\\VolatilityWorkbenchLog.txt"; //Contains the default Log file name
wchar_t					gFileName[MAXFILENAME + MAXDIRNAME];
unsigned int			gControlsList[] = { IDC_CHECK1, IDC_CHECK2, IDC_CHECK3, IDC_CHECK4, IDC_CHECK5, IDC_CHECK6, IDC_CHECK7, IDC_CHECK8, IDC_CHECK9, IDC_CHECK10, IDC_RADIO1, IDC_RADIO2, IDC_RADIO3, IDC_RADIO4, IDC_RADIO5, IDC_RADIO6, IDC_RADIO7, IDC_EDIT1, IDC_EDIT2, IDC_EDIT3, IDC_EDIT4, IDC_EDIT5, IDC_EDIT6, IDC_EDIT7, IDC_DROPDOWN1, IDC_DROPDOWN2, IDC_DROPDOWN3, IDC_DROPDOWN4, IDC_DROPDOWN5, IDC_DROPDOWN6, IDC_DROPDOWN7, IDC_GROUP1, IDC_GROUP2, IDC_GROUP3, IDC_GROUP4, IDC_GROUP5, IDC_GROUP6, IDC_GROUP7, IDC_GROUP8 };
ParamValue_t			gProcessList;
VOLATILITY_CMD_TYPEDEF	gCommands[TOT_COMMANDS] =
{
	{ L"All", L"user.script", L"User script", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_CHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},

	{ L"Windows", L"windows.amcache.Amcache", L"Extract information on executed applications from the AmCache", 0},
	{ L"Windows", L"windows.bigpools.BigPools", L"List big page pools", 1,
		{
			{ L"Show freed regions", L"--show-free", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.cachedump.Cachedump", L"Dumps lsa secrets from memory", 0},
	{ L"Windows", L"windows.callbacks.Callbacks", L"Lists kernel callbacks and notification routines", 0},
	{ L"Windows", L"windows.cmdline.CmdLine", L"Lists process command line arguments", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.cmdscan.CmdScan", L"Looks for Windows Command History lists", 2,
		{
			{ L"No Registry", L"--no-registry", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Max History", L"--max-history", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.consoles.Consoles", L"Looks for Windows console buffers", 3,
		{
			{ L"No Registry", L"--no-registry", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Max History", L"--max-history", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
			{ L"Max Buffers", L"--max-buffers", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT3, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.crashinfo.Crashinfo", L"Crashinfo", 0 },
	{ L"Windows", L"windows.debugregisters.DebugRegisters", L"windows.debugregisters.DebugRegisters", 0 },
	{ L"Windows", L"windows.devicetree.DeviceTree", L"Listing tree based on drivers and attached devices in a particular windows memory image", 0 },
	{ L"Windows", L"windows.dlllist.DllList", L"Lists the loaded modules in a particular windows memory image", 1,
		{
			{ L"Process ID", L"--pid ", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.driverirp.DriverIrp", L"List IRPs for drivers in a particular windows memory image", 0 },
	{ L"Windows", L"windows.drivermodule.DriverModule", L"Determines if any loaded drivers were hidden by a rootkit", 0 },
	{ L"Windows", L"windows.driverscan.DriverScan", L"Scans for drivers present in a particular windows	memory image", 0 },
	{ L"Windows", L"windows.dumpfiles.DumpFiles", L"Dumps cached file contents from Windows memory samples", 5,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			{ L"Virtual Address", L"--virtaddr", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_HEXADDRESS },
			{ L"Physical Address", L"--physaddr", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT3, NULL, VALIDATION_HEXADDRESS },
			{ L"Filter", L"--filter", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK4, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT4, NULL, VALIDATION_DISABLED },
			{ L"Ignore Case", L"--ignore-case", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK5, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.envars.Envars", L"Display process environment variables", 2,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			{ L"Suppress Variables", L"--silent", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.filescan.FileScan", L"Scans for file objects present in a particular windows memory image", 0 },
	{ L"Windows", L"windows.getservicesids.GetServiceSIDs", L"Lists process token sids", 0 },
	{ L"Windows", L"windows.getsids.GetSIDs", L"Print the SIDs owning each process", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.handles.Handles", L"Lists process open handles", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.hashdump.Hashdump", L"Dumps user hashes from memory", 0 },
	{ L"Windows", L"windows.hollowprocesses.HollowProcesses", L"Lists hollowed processes", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.iat.IAT", L"Extract Import Address Table to list API (functions) used by a program contained in external libraries", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.info.Info", L"Show OS & kernel details of the memory sample being analyzed", 0 },
	{ L"Windows", L"windows.joblinks.JobLinks", L"Print process job link information", 1,
		{
			{ L"Display physical offsets", L"--physical", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.kpcrs.KPCRs", L"Print KPCR structure for each processor", 0 },
	{ L"Windows", L"windows.ldrmodules.LdrModules", L"LdrModules", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	//{ L"Windows", L"windows.lsadump.Lsadump", L"Dumps lsa secrets from memory", 0 },
	{ L"Windows", L"windows.malfind.Malfind", L"Lists process memory ranges that potentially contain injected code.", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.mbrscan.MBRScan", L"Scans for and parses potential Master Boot Records (MBRs)", 1,
		{
			{ L"Full", L"--full", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.memmap.Memmap", L"Prints the memory map", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.mftscan.ADS", L"Scans for Alternate Data Stream", 0 },
	{ L"Windows", L"windows.mftscan.MFTScan", L"Scans for MFT FILE objects present in a particular windows memory image", 0 },
	{ L"Windows", L"windows.modscan.ModScan", L"Scans for modules present in a particular windows memory image", 0 },
	{ L"Windows", L"windows.modules.Modules", L"Lists the loaded kernel modules", 1,
		{
			{ L"Name", L"--name", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.mutantscan.MutantScan", L"Scans for mutexes present in a particular windows memory image", 0 },
	{ L"Windows", L"windows.netscan.NetScan", L"Scans for network objects present in a particular windows memory image", 1,
		{
			{ L"Include Corrupt", L"--include-corrupt", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.netstat.NetStat", L"Traverses network tracking structures present in a particular windows memory image", 1,
		{
			{ L"Include Corrupt", L"--include-corrupt", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.orphan_kernel_threads.Threads", L"Lists process threads", 0 },
	{ L"Windows", L"windows.pe_symbols.PESymbols", L"Prints symbols in PE files in process and kernel memory", 4,
		{
			{ L"Source", L"--source", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_CHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
			{ L"Module", L"--module", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
			{ L"Symbols", L"--symbols", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT3, NULL, VALIDATION_DISABLED },
			{ L"Addresses", L"--addresses", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK4, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT4, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.pedump.PEDump", L"Allows extracting PE Files from a specific address in a specific address space", 3,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			{ L"Base Address", L"--base", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
			{ L"Extract from Kernel", L"--kernel-module", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.poolscanner.PoolScanner", L"A generic pool scanner plugin", 0 },
	{ L"Windows", L"windows.privileges.Privs", L"Lists process token privileges", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.processghosting.ProcessGhosting", L"Lists processes whose DeletePending bit is set or whose FILE_OBJECT is set to 0", 0 },
	{ L"Windows", L"windows.pslist.PsList", L"Lists the processes present in a particular windows memory image", 2,
		{
			{ L"Display physical offsets", L"--physical", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.psscan.PsScan", L"Scans for processes present in a particular windows memory image", 2,
		{
			{ L"Display physical offsets", L"--physical", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.pstree.PsTree", L"Plugin for listing processes in a tree based on their parent process ID", 2,
		{
			{ L"Display physical offsets", L"--physical", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_RADIOBUTTON, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2,&gProcessList, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.psxview.PsXView", L"Lists all processes found via four of the methods described in \"The Art of Memory Forensics,\" which may help identify processes that are trying to hide themselves", 1,
		{
			{ L"Display physical offsets", L"--physical-offsets", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.registry.certificates.Certificates", L"Lists the certificates in the registry's Certificate Store", 0 },
	{ L"Windows", L"windows.registry.getcellroutine.GetCellRoutine", L"Reports registry hives with a hooked GetCellRoutine handler", 0 },
	{ L"Windows", L"windows.registry.hivelist.HiveList", L"Lists the registry hives present in a particular	memory image", 1,
		{
			{ L"Filter", L"--filter", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.registry.hivescan.HiveScan", L"Scans for registry hives present in a particular windows memory image", 0 },
	{ L"Windows", L"windows.registry.printkey.PrintKey", L"Lists the registry keys under a hive or specific key value", 3,
		{
			{ L"Hive Offset", L"--offset", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_HEXADDRESS },
			{ L"Key to start from", L"--key", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
			{ L"Recurses through keys", L"--recurse", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.registry.userassist.UserAssist", L"Print userassist registry keys and information", 1,
		{
			{ L"Hive Offset", L"--offset", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_HEXADDRESS }
		}
	},
	{ L"Windows", L"windows.scheduled_tasks.ScheduledTasks", L"Decodes scheduled task information from the Windows registry, including information about triggers, actions, run times, and creation times", 0 },
	{ L"Windows", L"windows.sessions.Sessions", L"Lists processes with Session information extracted from Environmental Variables", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.shimcachemem.ShimcacheMem", L"Reads Shimcache entries from the ahcache.sys AVL tree", 0 },
	{ L"Windows", L"windows.skeleton_key_check.Skeleton", L"Looks for signs of Skeleton Key malware", 0 },
	{ L"Windows", L"windows.ssdt.SSDT", L"Lists the system call table", 0 },
	{ L"Windows", L"windows.statistics.Statistics", L"Statistics", 0 },
	{ L"Windows", L"windows.strings.Strings", L"Reads output from the strings command and indicates which process(es) each string belongs to", 2,
		{
			{ L"Strings file", L"--strings-file", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_CHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.suspicious_threads.SupsiciousThreads", L"Lists suspicious userland process threads", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.svcdiff.SvcDiff", L"Compares services found through list walking versus scanning to find rootkits", 0 },
	{ L"Windows", L"windows.svclist.SvcList", L"Lists services contained with the services.exe doubly linked list of services", 0 },
	{ L"Windows", L"windows.svcscan.SvcScan", L"Scans for windows services", 0 },
	{ L"Windows", L"windows.symlinkscan.SymlinkScan", L"Scans for links present in a particular windows memory image", 0 },
	{ L"Windows", L"windows.thrdscan.ThrdScan", L"Scans for windows threads", 0 },
	{ L"Windows", L"windows.threads.Threads", L"Lists process threads", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.timers.Timers", L"Print kernel timers and associated module DPCs", 0 },
	{ L"Windows", L"windows.truecrypt.Passphrase", L"TrueCrypt Cached Passphrase Finder", 1,
		{
			{ L"Min-Length", L"--min-length", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.unhooked_system_calls.unhooked_system_calls", L"Looks for signs of Skeleton Key malware", 0 },
	{ L"Windows", L"windows.unloadedmodules.UnloadedModules", L"Lists the unloaded kernel modules", 0 },
	{ L"Windows", L"windows.vadinfo.VadInfo", L"Lists process memory ranges", 2,
		{
			{ L"Process virtual address", L"--address", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_HEXADDRESS },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED },
		}
	},
	{ L"Windows", L"windows.vadwalk.VadWalk", L"Walk the VAD tree", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.vadyarascan.VadYaraScan", L"Scans all the Virtual Address Descriptor memory maps using yara", 7,
		{
			{ L"Make case insensitive", L"--insensitive", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Match wide strings", L"--wide", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
			{ L"Rules (string)", L"--yara-rules", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT3, NULL, VALIDATION_DISABLED },
			{ L"Rules (file)", L"--yara-file", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK4, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT4, NULL, VALIDATION_DISABLED },
			{ L"Compiled rules (file)", L"--yara-compiled-file", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK5, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT5, NULL, VALIDATION_DISABLED },
			{ L"Maximum size", L"--max-size", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK6, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT6, NULL, VALIDATION_DIGIT },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK7, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN7, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.verinfo.VerInfo", L"Lists version information from PE files", 1,
		{
			{ L"Search physical layer", L"--extensive", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Windows", L"windows.virtmap.VirtMap", L"Lists virtual mapped sections", 0 },

	{ L"Mac", L"mac.bash.Bash", L"Recovers bash command history from memory", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Mac", L"mac.check_syscall.Check_syscall", L"Check system call table for hooks", 0 },
	{ L"Mac", L"mac.check_sysctl.Check_sysctl", L"Check sysctl handlers for hooks", 0 },
	{ L"Mac", L"mac.check_trap_table.Check_trap_table", L"Check mach trap table for hooks", 0 },
	{ L"Mac", L"mac.dmesg.Dmesg", L"Prints the kernel log buffer", 0 },
	{ L"Mac", L"mac.ifconfig.Ifconfig", L"Lists network interface information for all devices", 0 },
	{ L"Mac", L"mac.kauth_listeners.Kauth_listeners", L"Lists kauth listeners and their status", 0 },
	{ L"Mac", L"mac.kauth_scopes.Kauth_scopes", L"Lists kauth scopes and their status", 0 },
	{ L"Mac", L"mac.kevents.Kevents", L"Lists event handlers registered by processes", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Mac", L"mac.list_files.List_Files", L"Lists all open file descriptors for all processes", 0 },
	{ L"Mac", L"mac.lsmod.Lsmod", L"Lists loaded kernel modules", 0 },
	{ L"Mac", L"mac.lsof.lsof", L"Lists all open file descriptors for all processes", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Mac", L"mac.malfind.Malfind", L"Lists process memory ranges that potentially contain injected code", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Mac", L"mac.mount.Mount", L"A module containing a collection of plugins that produce data typically foundin Mac's mount command", 0 },
	{ L"Mac", L"mac.netstat.Netstat", L"Lists all network connections for all processes", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Mac", L"mac.proc_maps.Maps", L"Lists process memory ranges that potentially contain	injected code", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Mac", L"mac.psaux.Psaux", L"Recovers program command line arguments", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Mac", L"mac.pslist.PsList", L"Lists the processes present in a particular mac memory image", 2,
		{
			{ L"Method", L"--pslist-method", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Mac", L"mac.pstree.PsTree", L"Plugin for listing processes in a tree based on their	parent process ID", 0 },
	{ L"Mac", L"mac.socket_filters.Socket_filters", L"Enumerates kernel socket filters", 0 },
	{ L"Mac", L"mac.timers.Timers", L"Check for malicious kernel timers", 0 },
	{ L"Mac", L"mac.trustedbsd.Trustedbsd", L"Checks for malicious trustedbsd modules", 0 },
	{ L"Mac", L"mac.vfsevents.VFSevents", L"Lists processes that are filtering file system events", 0 },

	{ L"Linux", L"linux.bash.Bash", L"Recovers bash command history from memory", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.boottime.Boottime", L"VShows the time the system was started", 0 },
	{ L"Linux", L"linux.capabilities.Capabilities", L"Lists process capabilities", 1,
		{
			{ L"Process ID", L"--pids", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.check_afinfo.Check_afinfo", L"Verifies the operation function pointers of network protocols", 0 },
	{ L"Linux", L"linux.check_creds.Check", L"Checks if any processes are sharing credential structures", 0 },
	{ L"Linux", L"linux.check_idt.Check", L"Checks if the IDT has been altered", 0 },
	{ L"Linux", L"linux.check_modules.Check", L"Compares module list to sysfs info, if available", 0 },
	{ L"Linux", L"linux.check_syscall.Check_syscall", L"Check system call table for hooks", 0 },
	{ L"Linux", L"linux.ebpf.EBPF", L"Enumerate eBPF programs", 0 },
	{ L"Linux", L"linux.elfs.Elfs", L"Lists all memory mapped ELF files for all processes", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.envars.Envars", L"Lists processes with their environment variables", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.hidden_modules.Hidden_modules", L"Carves memory to find hidden kernel modules", 0 },
	{ L"Linux", L"linux.iomem.IOMem", L"Generates an output similar to /proc/iomem on a running system", 0 },
	{ L"Linux", L"linux.keyboard_notifiers.Keyboard", L"Parses the keyboard notifier call chain", 0 },
	{ L"Linux", L"linux.kmsg.Kmsg", L"Kernel log buffer reader", 0 },
	{ L"Linux", L"linux.kthreads.Kthreads", L"Enumerates kthread functions", 0 },
	{ L"Linux", L"linux.library_list.LibraryList", L"Enumerate libraries loaded into processes", 1,
		{
			{ L"Process ID", L"--pids", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.lsmod.Lsmod", L"Lists loaded kernel modules", 0 },
	{ L"Linux", L"linux.lsof.Lsof", L"Lists all memory maps for all processes", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.malfind.Malfind", L"Lists process memory ranges that potentially contain injected code", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.mountinfo.MountInfo", L"Lists mount points on processes mount namespaces", 3,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			{ L"Mount Namespace", L"--mntns", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
			{ L"Mount Point Info", L"--mount-format", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.netfilter.Netfilter", L"Lists Netfilter hooks", 0 },
	{ L"Linux", L"linux.pagecache.Files", L"Lists files from memory", 2,
		{
			{ L"File Types", L"--type", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
			{ L"Filename to Find", L"--find", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.pagecache.InodePages", L"Lists and recovers cached inode pages", 3,
		{
			{ L"Filename to Find", L"--find", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
			{ L"Inode Address", L"--inode", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
			{ L"Output File Path", L"--dump", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT3, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.pidhashtable.PIDHashTable", L"Enumerates processes through the PID hash table", 1,
		{
			{ L"Add brackets", L"--decorate-comm", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.proc.Maps", L"Lists all memory maps for all processes", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.psaux.PsAux", L"Lists processes with their command line arguments", 1,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.pslist.PsList", L"Lists the processes present in a particular linux memory image", 3,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			{ L"Include user threads", L"--threads", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Add brackets", L"--decorate-comm", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.psscan.PsScan", L"Scans for processes present in a particular linux image", 0 },
	{ L"Linux", L"linux.pstree.PsTree", L"Plugin for listing processes in a tree based on their parent process ID", 3,
		{
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			{ L"Include user threads", L"--threads", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Add brackets", L"--decorate-comm", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED }
		}
	},
	{ L"Linux", L"linux.ptrace.Ptrace", L"Enumerates ptrace's tracer and tracee tasks", 0 },
	{ L"Linux", L"linux.sockstat.Sockstat", L"Lists all network connections for all processes", 3,
		{
			{ L"Show UNIX only", L"--unix", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			{ L"Process ID", L"--pids", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED },
			{ L"Network Namespace", L"--netns", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT3, NULL, VALIDATION_DISABLED },
		}
	},
	{ L"Linux", L"linux.tty_check.tty", L"Checks tty devices for hooks", 0},
	{ L"Linux", L"linux.vmayarascan.VmaYaraScan", L"Scans all virtual memory areas for tasks using yara", 7,
		{
			{ L"Search case insensitive", L"--insensitive", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
			{ L"Match wide strings", L"--wide", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
			{ L"Rules (string)", L"--yara-rules", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT3, NULL, VALIDATION_DISABLED },
			{ L"Rules (file)", L"--yara-file", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK4, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT4, NULL, VALIDATION_DISABLED },
			{ L"Compiled rules (file)", L"--yara-compiled-file", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK5, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT5, NULL, VALIDATION_DISABLED },
			{ L"Maximum size", L"--max-size", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK6, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT6, NULL, VALIDATION_DIGIT },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK7, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN7, &gProcessList, VALIDATION_DISABLED },
		}
	},
};
wchar_t*				gPlatforms[NUM_PLATFORMS] = { L"Windows", L"Linux", L"Mac" };
wchar_t					gPlatform[10];
PROCESS_INFORMATION		gProcessInfo;
bool					gCommandRunning = false;
wchar_t					gKDBG_Addr[MAX_KDBG_ADDR_LEN];
CRITICAL_SECTION		LogCritSection;
wchar_t					gStrProgress[100] = { L'\0' };
int						gNumScript = 0;
wchar_t					gScriptFileNames[NUM_SCRIPTS][MAXFILENAME + MAXDIRNAME];

#else

extern	HWND					ghMainWnd;
extern	char					lastURL[MAX_URL_LEN];;
extern	wchar_t					fullpath[MAXFILENAME + MAXDIRNAME];
extern	wchar_t					szDefaultLogName[MAXFILENAME];
extern	wchar_t					RunDirName[MAXDIRNAME];
extern	wchar_t					gFileName[MAXFILENAME + MAXDIRNAME];
extern	unsigned int			gControlsList[17];
extern	VOLATILITY_CMD_TYPEDEF	gCommands[TOT_COMMANDS];
extern	wchar_t*				gPlatforms[NUM_PLATFORMS];
extern	wchar_t					gPlatform[10];
extern	PROCESS_INFORMATION		gProcessInfo;
extern	bool					gCommandRunning;
extern	wchar_t					gKDBG_Addr[MAX_KDBG_ADDR_LEN];
extern	CRITICAL_SECTION		LogCritSection;
extern	wchar_t					gStrProgress[100];
extern	int						gNumScript;
extern	wchar_t					gScriptFileNames[NUM_SCRIPTS][MAXFILENAME + MAXDIRNAME];

#endif

// Prototypes
HANDLE SpawnWithRedirect(wchar_t* ProgName, PROCESS_INFORMATION* ProcessInfo, HANDLE* hChildStdOut, HANDLE* hChildStdErr);

#endif //VOLATILITY_WORKBENCH_H